const Discord = require('discord.js');
const chalk = require('chalk');

module.exports = (client, node, error) => {
    if (error.message.includes('Unexpected op "ready"')) return;

    console.log(
        chalk.red.bold('ERROR'),
        chalk.white('>>'),
        chalk.white('Node'),
        chalk.red(`${node.options.identifier}`),
        chalk.white('had an error:'),
        chalk.red(`${error.message}`)
    );
};
