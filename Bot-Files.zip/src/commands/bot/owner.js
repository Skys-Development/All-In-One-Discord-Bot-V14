const Discord = require('discord.js');

module.exports = async (client, interaction, args) => {
    client.embed({
        title: `📘・Owner information`,
        desc: `____________________________`,
        thumbnail: client.user.avatarURL({ dynamic: true, size: 1024 }),
        fields: [{
            name: "👑┆Owner name",
            value: `William2Sober`,
            inline: true,
        },
        {
            name: "🏷┆Discord tag",
            value: `<@1342676516353343513>`,
            inline: true,
        },
        {
            name: "🏢┆Organization",
            value: `William's Projects`,
            inline: true,
        },
        {
            name: "🌐┆Website",
            value: `https://willy.us.kg`,
            inline: true,
        }],
        type: 'editreply'
    }, interaction)
}

 