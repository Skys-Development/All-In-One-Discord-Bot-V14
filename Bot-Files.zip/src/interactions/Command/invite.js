const { SlashCommandBuilder, Client, CommandInteraction, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('invite')
        .setDescription('Get an invite to the bot'),

    /**
     * @param {Client} client
     * @param {CommandInteraction} interaction
     * @param {String[]} args
     */
    run: async (client, interaction, args) => {
        await interaction.deferReply({ fetchReply: true });

        const row = new ActionRowBuilder().addComponents(
            new ButtonBuilder()
                .setLabel('Invite')
                .setURL(client.config.discord.botInvite)
                .setStyle(ButtonStyle.Link),

            new ButtonBuilder()
                .setLabel('Support Server')
                .setURL(client.config.discord.serverInvite)
                .setStyle(ButtonStyle.Link)
        );

        client.embed({
            title: '📨・Invite',
            desc: 'Make your server even better with Bot!',
            url: client.config.discord.botInvite,
            components: [row],
            type: 'editreply',
        }, interaction);
    },
};
